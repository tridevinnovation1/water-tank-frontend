import React from 'react'
import Header from '../components/Header'
const Contact = () => {
  return (
    <div>
      <Header />
      <div className='h-[75vh] w-[85%] flex justify-center items-center bg-slate-300'>

        Contact
      </div>
    </div>
  )
}

export default Contact